/******************************************************************************
 *
 * E X T E R N A L   B R I D G E   B O D Y
 *
 * NAME: ARCH
 *
 *
 *
 ******************************************************************************/

#include "PhoneX/ComponentLibrary/PhoneX/ImplementationPkg/ARCH.hh"
#include "PhoneX/ComponentLibrary/PhoneX/PhoneX_def.hh"
#include <cstdlib>

void (::PhoneX::ComponentLibrary::PhoneX::ImplementationPkg::ARCH::shutdown)() {
	exit(0);
}
